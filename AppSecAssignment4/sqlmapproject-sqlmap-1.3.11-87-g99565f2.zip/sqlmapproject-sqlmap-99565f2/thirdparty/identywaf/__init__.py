#!/usr/bin/env python
#
# Copyright (c) 2019 Miroslav Stampar (@stamparm), MIT
# See the file 'LICENSE' for copying permission

# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.

pass
